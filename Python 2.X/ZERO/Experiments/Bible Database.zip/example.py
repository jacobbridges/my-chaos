import sqlite3

# print sqlite3.connect('bible13.db').execute('select text from verses where book=? and chap=? and vers=?', (66, 22, 13)).fetchone()[0]

REF = 66, 22, 13

con = sqlite3.connect('bible13.db')
cur = con.execute('''select text from verses where
                     book=? and chap=? and vers=?''', REF)
tup = cur.fetchone()
uni = tup[0]

raw_input(uni)
