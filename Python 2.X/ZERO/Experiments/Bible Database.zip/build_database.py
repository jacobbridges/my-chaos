import sqlite3

def main():
    # get and parse Bible
    bible = open('bible13.txt', 'rU')
    string = bible.read()
    bible.close()
    array = parse(string)
    # create the database
    database = sqlite3.connect('bible13.db')
    database.execute('''create table verses
    (book integer, chap integer, vers integer, text text)''')
    # add verses to table
    for b_index, book in enumerate(array):
        for c_index, chap in enumerate(book):
            for v_index, vers in enumerate(chap):
                database.execute('insert into verses values (?,?,?,?)',
                                 (b_index + 1, c_index + 1, v_index + 1, vers))
    # commit and close DB
    database.commit()
    database.close()

def parse(string):
    book = chap = vers = 1
    form = '%02u:%03u:%03u'
    book_s, chap_s, vers_s = [], [], []
    start = 0
    while True:
        try:
            start = string.index(form % (book, chap, vers), start) + 11
            end = string.index('\n\n', start)
            vers_s.append(' '.join(string[start:end].replace('\n', '').split()))
            start = end
            vers += 1
        except:
            if vers != 1:
                chap_s.append(vers_s)
                vers_s = []
                chap += 1
                vers = 1
            elif chap != 1:
                book_s.append(chap_s)
                chap_s = []
                book += 1
                chap = 1
            elif book != 1:
                return book_s
            else:
                raise EOFError

if __name__ == '__main__':
    main()
